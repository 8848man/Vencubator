# SPEC-010 — Vencubator 랜딩 v3 “뿌리”

Revision 0.1 · Implemented (L04-W01) · AUTH-010 · 2026-09-26

사용자 요청: “재구성해서 v3 프로토타입을 만들 수 있나? 너무 배낀 티가 안나게끔”. 근거 [PRINCIPLES](PRINCIPLES.md)(DP-1~12), 사이트 계약 [SPEC-009](../../docs/specs/SPEC-009-site.md), 검증 [VAL-L03](VAL-L03.md). v1(SPEC-006)·v2(SPEC-007)는 수정하지 않는다.

## 1. 범위

| 포함 | 제외 |
|---|---|
| 정적 단일 페이지, 이름표 입력 → 지층 4개 체험(퀴즈·질문·관찰 해석·결정) → 뿌리 지도 → 위와 아래(부캐/본캐) → 솔직한 안내 → 앱에서 심기. 스크롤에 따라 그려지는 뿌리, 깊이 눈금, 반응형, 모션 감소, 로컬 저장, 단일 파일 빌드, 공개 빌드 | 서버 전송, 실제 AI, 외부 배포, A/B 순환 편입(비율 0) |

## 2. 파일 계약

v2와 같은 구조: `src/content.mjs`(카피) · `src/state.mjs`(순수 상태, v2 모델 계승) · `src/render.mjs`(순수 렌더) · `src/interact.mjs`(이벤트·뿌리·깊이) · `src/track.mjs`(site/shared 복사본) · `src/tokens.css` · `src/landing.css` · `scripts/build.mjs`(opts.public, opts.outFile) · `scripts/serve.mjs`(4176, `/app/` 연결) · `scripts/qa.mjs` · `start.cmd`.

## 3. 섹션 계약

| ID | type | 지층·깊이 | 기억될 장면 (DP-10) | 상호작용 |
|---|---|---|---|---|
| L3S-00 | `topbar` | — | 브랜드, 처음부터, 앱 열기 | L3I-07 |
| L3S-01 | `surface` | 지상 | 지평선 위 새싹과 크게 꽂힌 **이름표 입력** | L3I-01, L3I-02 |
| L3S-02 | `gauge` | 전체 | 왼쪽 가장자리 **깊이 눈금**과 **뿌리 줄기** | — |
| L3S-03 | `layerLearn` | 0–15cm 겉흙 | 개념 한 줄(큰 세리프) + 퀴즈 | L3I-03 |
| L3S-04 | `layerAsk` | 15–40cm 속흙 | 내 고객 이름(손글씨) + 질문 3개 | L3I-04 |
| L3S-05 | `layerObserve` | 40–70cm 깊은 흙 | 들은 답 3개, **방향을 트는 뿌리** | L3I-05 |
| L3S-06 | `layerDecide` | 70–100cm 깊은 흙 | 결정 선택지 3개 | L3I-06 |
| L3S-07 | `rootMap` | 100cm 아래 | **일곱 갈래 뿌리 지도**, 지금·다음 갈래 | (L3I-05 결과 반영) |
| L3S-08 | `aboveBelow` | 지표 단면 | 위(줄기=부캐) / 아래(뿌리=본캐) 분할 | — |
| L3S-09 | `honest` | 지상 | 진행 상황 3행 + 자주 묻는 질문 | — |
| L3S-10 | `harvest` | 지상 | 자란 새싹과 **내 이름표**, 앱에서 심기 | L3I-08 |
| L3S-11 | `footer` | — | 고지 | — |

제약: `<h1>` 1개. 각 지층 제목 옆에 **실제 뜻**을 항상 병기(예: “0–15cm · 오늘 배울 것”). 테두리 있는 판은 조작 가능한 요소에만. 스크롤 고정(sticky) 무대 없음(상단바만 sticky).

## 4. 상태 모델

v2 `state.mjs`와 같은 액션·파생 규칙을 쓴다(SPEC-007 §4). 차이: 저장 키 `vencubator.landing.v3`, 칸 이름(이름표·배운 것·질문·들은 답·결정), `deriveCard.status`의 `example` 값은 **다 쓴 예시 기록 문장**(빈 안내문 아님). `rootState(state)` 추가: 층별 `mine|example`, 반박 여부.

## 5. 상호작용

| ID | 트리거 | 결과 |
|---|---|---|
| L3I-01 | 이름표 제출(“심기”) | SET_IDEA mine → 겉흙으로 스크롤, 이름표 흔들림 1회 |
| L3I-02 | 예시 칩 | SET_IDEA example+sample, 이름표에 반영 |
| L3I-03 | 퀴즈 선택 | ANSWER, 즉시 피드백, 오답이면 다른 문항 |
| L3I-04 | 고객 입력 / 저장 | 질문 갱신 / SAVE_QUESTIONS |
| L3I-05 | 같았어요/달랐어요 | OBSERVE. 달랐어요 → 뿌리 우회 그리기 + 뿌리 지도에서 전략 갈래가 “다음” |
| L3I-06 | 결정 | DECIDE |
| L3I-07 | 처음부터 | RESET |
| L3I-08 | 앱에서 심기 | `../app/?from=v3` 같은 탭 이동. 앱은 `vencubator.landing.v3`의 문장만 가져온다(SPEC-009 §5 확장) |
| L3I-09 | 모든 변경 | 로컬 저장, 새로고침 복원 |

## 6. 모션

| ID | 대상 | 규칙 |
|---|---|---|
| L3M-01 | 뿌리 줄기 | 흙 구간 진행률 p = (scrollY + 0.6vh − 흙 시작) / 흙 높이. `stroke-dashoffset = 길이 × (1−p)`. rAF 1회 스로틀. 고정 없음 |
| L3M-02 | 깊이 눈금 | 층 경계(0·15·40·70·100cm) 눈금과, 뿌리 끝을 따라다니는 현재 깊이·지층 이름(층 경계 사이 선형 보간). 좁은 화면에서는 깊이 숫자만 |
| L3M-03 | 층 뿌리 | 내가 채운 층의 곁뿌리는 연두 실선으로 그려짐(600ms), 예시 층은 점선 |
| L3M-04 | 우회 뿌리 | 반박 시 관찰 층 기록 높이에서 줄기가 옆으로 꺾이고(폭 `--rail-turn`, 좁은 화면에서 줄임), 원래 방향으로 조금 뻗다 멈춘 막힌 뿌리가 주황 점선으로 남는다 |
| L3M-05 | 이름표 입력 | 비어 있고 포커스가 없을 때 예시 문장이 손글씨로 한 글자씩 써짐(순환). 입력·포커스 시 멈춤 |
| L3M-06 | 층 진입 | 첫 진입 시 글이 흙에서 떠오르듯 12px 상승 + 불투명 (초기 상태도 읽을 수 있는 불투명도 0.35 이상) |
| L3M-07 | 새싹 | 채운 층 수로 자람(v2 `--grow`) |

`prefers-reduced-motion`: 뿌리·눈금은 최종 상태, 타이핑·흔들림 없음, 진입 효과 없음.

## 7. 수용 기준

| AC | 기준 | 검사 |
|---|---|---|
| AC-L3-01 | §3 표 ↔ `SECTIONS` id·type·순서 일치, L3I·L3M ID가 코드에 존재 | tests/spec.test.mjs |
| AC-L3-02 | 상태 모델: v2 규칙 동일 + 예시 값이 빈 안내문이 아님 + rootState | tests/state.test.mjs |
| AC-L3-03 | 렌더: h1 1개, 모든 입력 label, 버튼 type, 지층 제목에 뜻 병기, 이름표 입력 존재 | tests/render.test.mjs |
| AC-L3-04 | 카피 금지 표현 없음, 필수 고지, 예시 표기 | tests/content.test.mjs |
| AC-L3-05 | CSS: hex는 tokens에만, sticky는 상단바만, 100vh 초과 높이 없음. 참고 사이트 장치 흔적(거대 인덱스 숫자, 하단 고정 CTA, 챕터 번호 내비) 없음 | tests/content.test.mjs |
| AC-L3-06 | 네트워크 전송 코드 없음, 입력은 textContent로만 | tests/content.test.mjs |
| AC-L3-07 | 7영역 이름·색 = prototype STATS, 퀴즈 = LESSONS, 상태 행 = STATE.json | tests/spec.test.mjs |
| AC-L3-08 | 브라우저: 입력→이름표·겉흙 반영, 퀴즈 오답→정답, 고객→질문, 달랐어요→우회 뿌리·전략 다음, 결정→완성, 스크롤에 따라 뿌리 길이·깊이 증가, 새로고침 복원, 1440·390·모션 감소, 가로 스크롤 0, JS 오류 0 | scripts/qa.mjs |
| AC-L3-09 | 단일 파일 빌드·공개 빌드(내부 문서 링크 없음) | tests/build.test.mjs |
